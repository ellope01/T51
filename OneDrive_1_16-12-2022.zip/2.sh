#!/bin/bash
echo
read -p "Introduce un numero mayor que 0: " num
if [ $num%2 -ne 0 ]
then
	echo "El numero intoducido es non"
else
	echo "El numero introducido es par"
fi
