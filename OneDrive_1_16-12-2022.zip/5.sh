#!/bin/bash
read -p "Introduce un valor distinto de 0" num
echo "Cuando el numero introducido sea 0 el programa se detendra"
while [ $num -eq 0]; do
var contador= 0
contador +1
done
