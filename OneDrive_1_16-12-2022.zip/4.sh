#!/bin/bash
read -p "Introduce un numero mayor de 0: " num
while [ $num -ne 0 ];
do
resultado= $((num - 1))
echo "$resultado"
done
