#!/bin/bash
echo
read -p "Introduce la nota del alumno: " nota
if [ $nota -gt 4 ]
then
	echo "El alumno está aprobado"
elif [ $nota -gt 9 ]
	echo "El alumno tiene un sobresaliente"
elif [ $nota -gt 7 ]
	echo "El alumno tiene un notable"
else
	echo "El alumno está supendido"
fi 

